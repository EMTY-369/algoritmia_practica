# Empty compiler generated dependencies file for 2024304_LAB1P2.
# This may be replaced when dependencies are built.
