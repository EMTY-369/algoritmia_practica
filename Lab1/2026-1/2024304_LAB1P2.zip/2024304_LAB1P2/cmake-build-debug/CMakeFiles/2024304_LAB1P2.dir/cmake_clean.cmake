file(REMOVE_RECURSE
  "CMakeFiles/2024304_LAB1P2.dir/link.d"
  "2024304_LAB1P2"
  "2024304_LAB1P2.pdb"
  "CMakeFiles/2024304_LAB1P2.dir/main.cpp.o"
  "CMakeFiles/2024304_LAB1P2.dir/main.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/2024304_LAB1P2.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
